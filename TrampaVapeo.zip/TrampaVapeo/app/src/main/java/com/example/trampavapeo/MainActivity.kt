package com.example.trampavapeo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import com.example.trampavapeo.ui.theme.TrampaVapeoTheme

import com.example.trampavapeo.ui.screens.*
import com.example.trampavapeo.data.Screen
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TrampaVapeoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        startDestination = Screen.Welcome.route
                    ) {
                        composable(Screen.Welcome.route) { OnbordingScreen(navController) }
                        composable(Screen.Clicker.route) { ClickerScreen(navController) }
                        composable(Screen.Tolerance.route) { ToleranceScreen(navController) }
                        composable(Screen.Critical.route) { CriticalScreen(navController) }
                        composable(Screen.CoughLock.route) { CoughLockScreen(navController) }
                        composable(Screen.Defeat.route) { DefeatScreen(navController) }
                        composable(Screen.Victory.route) { VictoryScreen(navController) }


                    }
                }
            }
        }
    }
}


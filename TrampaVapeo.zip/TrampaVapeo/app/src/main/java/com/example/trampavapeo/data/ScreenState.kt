package com.example.trampavapeo.data

sealed class Screen (val route: String, val number: String, val title: String){
    object Welcome : Screen("welcome", "01", "Pantalla de Bienvenida")
    object Clicker : Screen("clicker", "02", "La Trampa Dorada")
    object Tolerance : Screen("tolerance", "03", "Tolerancia Biológica")
    object Critical : Screen("critical", "04", "Fase Crítica & Taquicardia")
    object CoughLock : Screen("cough_lock", "05", "Cough Lock: bloqueo")
    object Defeat : Screen("defeat", "06", "Desenlace A: El Colapso")
    object Victory : Screen("victory", "07", "Desenlace B: Salida Consciente")
}
package com.example.trampavapeo.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun AnimatedLugs(state: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "lugs")

    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (state == "healthy") 1.08f else 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (state == "healthy") 3600 else 1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "lungScale"
    )

    Canvas(modifier = Modifier.size(80.dp)) {
        val lungColor = when (state) {
            "healthy" -> Color(0xFF34D399)
            "warning" -> Color(0xFFF59E0B)
            "critical" -> Color(0xFF10B981)
            else -> Color(0xFF10B981)
        }
        drawCircle(
            color = lungColor,
            radius = size.minDimension / 3f * scale,
            center = center
        )
    }
}
package com.example.trampavapeo.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.trampavapeo.data.Screen
import kotlinx.coroutines.delay

@Composable
fun OnbordingScreen(navController: NavController) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFF8FAFC)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                color = Color(0xFFEEF2FF),
                shape = RoundedCornerShape(50.dp),
                modifier = Modifier.border(1.dp, Color(0xFFC7D2FE), RoundedCornerShape(50.dp))
            ) {
                Text(
                    text = "SESIÓN RÁPIDA (3:00 MINUTOS)",
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    color = Color(0xFF4F46E5),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "LA TRAMPA DEL VAPER",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF0F172A),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "\"ENCENDÉ TU TRANQUILIDAD\"",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF06B6D4)
                )

                Spacer(modifier = Modifier.height(28.dp))

                Box(
                    modifier = Modifier
                        .width(110.dp)
                        .height(180.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF0F172A)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(36.dp)
                                .height(16.dp)
                                .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                .background(Color(0xFF334155))
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF22D3EE).copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "50mg Nic", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF06B6D4)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "⚡", color = Color.White, fontSize = 10.sp)
                        }

                        Text(text = "POD SLIM", fontSize = 8.sp, color = Color.LightGray, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Hacé clic sobre el pod para calmar la mente y liberar tensión.",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        navController.navigate(Screen.Clicker.route)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06B6D4))
                ) {
                    Text(
                        text = "▶ EMPEZAR EXPERIENCIA (3:00)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Text(
                    text = "*Regla invisible: Cada clic tiene consecuencias biológicas.",
                    fontSize = 10.sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
@Composable
fun ClickerScreen(navController: NavController) {
    var calmaPoints by remember { mutableStateOf(1840) }

    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 1.05f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "vapePulse"
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(text = "SENSACIÓN DE CALMA", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                        Text(text = "✨ $calmaPoints pts", fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color(0xFFD97706))
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFA7F3D0)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🫁", fontSize = 18.sp)
                    }
                    Column {
                        Text(text = "SALUD PULMONAR", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text(text = "100% • ÓPTIMA", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color(0xFF059669))
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "+25 Calma Instantánea ✨",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF06B6D4),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                Box(
                    modifier = Modifier
                        .scale(scale)
                        .width(130.dp)
                        .height(220.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF0F172A))
                        .clickable {
                            // Al hacer clic, sumamos puntos y activamos efecto visual
                            calmaPoints += 25
                            isPressed = !isPressed
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(40.dp)
                                .height(20.dp)
                                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                .background(Color(0xFF334155))
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(45.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF22D3EE).copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "Nic-Salt 50mg", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF06B6D4)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "▼", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Text(text = "POD SLIM", fontSize = 8.sp, color = Color.LightGray, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        calmaPoints += 25
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFECFEFF)),
                    shape = RoundedCornerShape(50.dp)
                ) {
                    Text(
                        text = "[ CLIC PARA PITADA DE NICOTINA ]",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0E7490)
                    )
                }
            }

            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        navController.navigate(Screen.Tolerance.route)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                ) {
                    Text(text = "Siguiente: Fase de Tolerancia ➔", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun ToleranceScreen(navController: NavController) {
    var calmaPoints by remember { mutableStateOf(5120) }

    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 1.05f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "vapeTolerancePulse"
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFFAF6F0)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(text = "CALMA REAL", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                        Text(text = "📉 $calmaPoints pts", fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color(0xFFB45309))
                    }
                }

                // Indicador de Pulmón Irritado
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFDE68A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🫁", fontSize = 18.sp)
                    }
                    Column {
                        Text(text = "CAPACIDAD", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                        Text(text = "72% • RESIDUO TÓXICO", fontSize = 10.sp, fontWeight = FontWeight.Black, color = Color(0xFFB45309))
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(text = "⚠️", fontSize = 18.sp, modifier = Modifier.padding(end = 8.dp))
                    Column {
                        Text(
                            text = "ADVERTENCIA: TOLERANCIA QUÍMICA DESARROLLADA",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF78350F)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Los receptores nicotínicos se han saturado. Cada calada produce -50% de calma. Necesitás clickear el doble para evitar la ansiedad.",
                            fontSize = 10.sp,
                            color = Color(0xFF92400E),
                            lineHeight = 13.sp
                        )
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "+10 Pts (DEVALUADO • RESISTENCIA QUEMADA)",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF92400E),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Box(
                    modifier = Modifier
                        .scale(scale)
                        .width(130.dp)
                        .height(210.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF451A03))
                        .clickable {
                            calmaPoints += 10
                            isPressed = !isPressed
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(40.dp)
                                .height(20.dp)
                                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                .background(Color(0xFF1C1917))
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(45.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFD97706).copy(alpha = 0.5f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "COIL RECALENTADA",
                                fontSize = 8.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFD97706)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "x2", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }

                        Text(text = "TOLERANCIA ACTIVA", fontSize = 8.sp, color = Color(0xFFFDE68A), fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { calmaPoints += 10 },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFEF3C7)),
                    shape = RoundedCornerShape(50.dp)
                ) {
                    Text(
                        text = "[ CLIC RÁPIDO: EL CUERPO PIDE MÁS ]",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF78350F)
                    )
                }
            }

            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Frecuencia cardíaca acelerada • Respiración irregular detectada.",
                    fontSize = 9.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        navController.navigate(Screen.Critical.route)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                ) {
                    Text(text = "Avanzar a Fase Crítica ➔", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}
@Composable
fun CriticalScreen(navController: NavController) {
    var calmaPoints by remember { mutableIntStateOf(68430) }

    var totalSeconds by remember { mutableIntStateOf(10) }
    // Corrutina que descuente 1 segundo cada 1000 ms
    LaunchedEffect(key1 = totalSeconds) {
        if (totalSeconds > 0) {
            delay(1000L)
            totalSeconds--
        } else {
            // Cuando el tiempo llega a 0, se activa automáticamente el bloqueo por tos
            navController.navigate(Screen.CoughLock.route) {
                popUpTo(Screen.Critical.route) { inclusive = true }
            }
        }
    }

    val formattedTime = remember(totalSeconds) {
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        String.format("%02d:%02d", minutes, seconds)
    }

    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 1.08f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioHighBouncy),
        label = "criticalPulse"
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF141211)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF450A0A)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.border(1.dp, Color(0xFFDC2626), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(text = "ALERTA VITAL", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFCA5A5))
                        // Muestra el tiempo actualizado segundo a segundo
                        Text(text = "⏱ $formattedTime", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Color.White)
                    }
                }

                // Estado biológico crítico
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF7F1D1D)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🫁", fontSize = 18.sp)
                    }
                    Column {
                        Text(text = "¡TAQUICARDIA!", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFCA5A5))
                        Text(text = "21% • COLAPSO", fontSize = 10.sp, fontWeight = FontWeight.Black, color = Color(0xFFEF4444))
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF450A0A)),
                    shape = RoundedCornerShape(50.dp),
                    modifier = Modifier
                        .padding(bottom = 16.dp)
                        .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(50.dp))
                ) {
                    Text(
                        text = "🚨 BRONCOESPASMO • SOBREDOSIS DIGITAL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFCA5A5),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .scale(scale)
                        .width(130.dp)
                        .height(210.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF0C0A09))
                        .border(2.dp, Color(0xFFE11D48), RoundedCornerShape(24.dp))
                        .clickable {
                            calmaPoints += 1
                            isPressed = !isPressed
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(40.dp)
                                .height(20.dp)
                                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                .background(Color.Black)
                                .border(1.dp, Color(0xFFE11D48), RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        )

                        // Fuga de líquido
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(45.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1C1917)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "! FUGA QUÍMICA !",
                                fontSize = 8.sp,
                                color = Color(0xFFF87171),
                                fontWeight = FontWeight.Black
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE11D48)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "⚡", color = Color.White, fontSize = 12.sp)
                        }

                        Text(text = "NO PODÉS PARAR", fontSize = 8.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF450A0A)),
                    shape = RoundedCornerShape(50.dp),
                    modifier = Modifier.border(1.dp, Color(0xFFB91C1C), RoundedCornerShape(50.dp))
                ) {
                    Text(
                        text = "[ CLIC DESESPERADO POR ALIVIO ]",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFCA5A5),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }

            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Respuesta Compulsiva:",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFCA5A5)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF290A0A)),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, Color(0xFF881337), RoundedCornerShape(8.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "OTRO POD", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(text = "-18% Salud", fontSize = 8.sp, color = Color(0xFFF87171))
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF290A0A)),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, Color(0xFF881337), RoundedCornerShape(8.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "50MG PURO", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF87171))
                            Text(text = "-30% Salud", fontSize = 8.sp, color = Color(0xFFF87171))
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF290A0A)),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, Color(0xFF881337), RoundedCornerShape(8.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "FORZAR", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(text = "-40% Salud", fontSize = 8.sp, color = Color(0xFFF87171))
                        }
                    }
                }

                Button(
                    onClick = {
                        navController.navigate(Screen.CoughLock.route)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48))
                ) {
                    Text(
                        text = "Simular Bloqueo por Tos (Cough Lock) ➔",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
@Composable
fun CoughLockScreen(navController: NavController) {
    var timeLeft by remember { mutableFloatStateOf(1.8f) }
    var isUnlocked by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (timeLeft > 0f) {
            delay(100)
            timeLeft -= 0.1f
        }
        timeLeft = 0f
        isUnlocked = true
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF141211)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1917)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, Color(0xFFE11D48), RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Surface(
                        color = Color(0xFF450A0A),
                        shape = RoundedCornerShape(50.dp),
                        modifier = Modifier.border(1.dp, Color(0xFFE11D48), RoundedCornerShape(50.dp))
                    ) {
                        Text(
                            text = "💥 COUGH LOCK // ACCESO DE TOS",
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            color = Color(0xFFFCA5A5),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF450A0A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🫁💥", fontSize = 32.sp)
                    }

                    Text(
                        text = "\"NO ENTRA EL AIRE\"",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFEF4444),
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "Los bronquios colapsaron por inhalación repetida. Las entradas de ratón y pantalla se suspenden por seguridad del sistema.",
                        fontSize = 12.sp,
                        color = Color(0xFFD6D3D1),
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Reactivando sensores en:", fontSize = 11.sp, color = Color.Gray)
                            Text(
                                text = if (isUnlocked) "¡SISTEMA LIBERADO!" else String.format("%.1f s...", timeLeft),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFCA5A5)
                            )
                        }

                        LinearProgressIndicator(
                            progress = { 1f - (timeLeft / 1.8f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(50.dp)),
                            color = Color(0xFFE11D48),
                            trackColor = Color(0xFF292524)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    if (!isUnlocked) {
                        Surface(
                            color = Color(0xFF292524),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "🔒 DISPARADOR DE VAPER BLOQUEADO",
                                modifier = Modifier.padding(vertical = 14.dp),
                                color = Color.Gray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { navController.navigate(Screen.Defeat.route) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                            ) {
                                Text(text = "Continuar Clickeando ➔ (Desenlace A)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { navController.navigate(Screen.Victory.route) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF34D399))
                            ) {
                                Text(text = "Soltar el celular ➔ (Desenlace B)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
@Composable
fun DefeatScreen(navController: NavController) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F0E0E)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    color = Color(0xFF450A0A),
                    shape = RoundedCornerShape(50.dp),
                    modifier = Modifier.border(1.dp, Color(0xFFEF4444), RoundedCornerShape(50.dp))
                ) {
                    Text(
                        text = "DESENLACE A // COLAPSO COMPULSIVO",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        color = Color(0xFFFCA5A5),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "\"LA ILUSIÓN DEL CONTROL\"",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFFEF4444),
                    textAlign = TextAlign.Center
                )
            }

            // --- ÁREA CENTRAL: ANULACIÓN DE PUNTOS Y DATOS BIOLÓGICOS ---
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f).wrapContentHeight()
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF290A0A))
                        .border(2.dp, Color(0xFF7F1D1D), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🫁🔥", fontSize = 42.sp)
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1917)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF450A0A), RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "SENSACIÓN DE CALMA RETENIDA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text(text = "0 PTS", fontSize = 36.sp, fontWeight = FontWeight.Black, color = Color(0xFFEF4444))
                        Text(
                            text = "Toda la 'calma' obtenida fue el alivio temporal del síndrome de abstinencia que el mismo pod generó.",
                            fontSize = 11.sp,
                            color = Color(0xFFA8A29E),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1917)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "NICOTINA", fontSize = 9.sp, color = Color.Gray)
                            Text(text = "+150 mg", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFCA5A5))
                        }
                    }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1917)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "PULMONES", fontSize = 9.sp, color = Color.Gray)
                            Text(text = "CRÍTICO", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444))
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        navController.navigate(Screen.Welcome.route) {
                            popUpTo(Screen.Welcome.route) { inclusive = true }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(text = "↺ Reiniciar Simulación", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }

                OutlinedButton(
                    onClick = { navController.navigate(Screen.Victory.route) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF34D399))
                ) {
                    Text(text = "Ver Desenlace Consciente ➔", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
@Composable
fun VictoryScreen(navController: NavController) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFF0FDF4)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    color = Color(0xFFDCFCE7),
                    shape = RoundedCornerShape(50.dp),
                    modifier = Modifier.border(1.dp, Color(0xFF86EFAC), RoundedCornerShape(50.dp))
                ) {
                    Text(
                        text = "DESENLACE B // SALIDA CONSCIENTE",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        color = Color(0xFF166534),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "\"LIBERTAD REGENERATIVA\"",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF15803D),
                    textAlign = TextAlign.Center
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f).wrapContentHeight()
            ) {
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDCFCE7))
                        .border(2.dp, Color(0xFF4ADE80), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🫁🌿", fontSize = 46.sp)
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFBBF7D0), RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "CALMA REAL RESTAURADA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF15803D))
                        Text(text = "100%", fontSize = 38.sp, fontWeight = FontWeight.Black, color = Color(0xFF16A34A))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Elegiste soltar el ciclo. Tu sistema nervioso recupera la capacidad natural de autorregular el estrés sin químicos externos.",
                            fontSize = 11.sp,
                            color = Color(0xFF374151),
                            textAlign = TextAlign.Center,
                            lineHeight = 16.sp
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.weight(1f).border(1.dp, Color(0xFFDCFCE7), RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "OXIGENACIÓN", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text(text = "ÓPTIMA", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                        }
                    }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.weight(1f).border(1.dp, Color(0xFFDCFCE7), RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "ANSIEDAD", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text(text = "REDUCIDA", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0D9488))
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        // Reiniciar la simulación desde la bienvenida
                        navController.navigate(Screen.Welcome.route) {
                            popUpTo(Screen.Welcome.route) { inclusive = true }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                ) {
                    Text(text = "↺ Volver a la Experiencia", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}